<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Http\Controllers\LoanController;
class Loan extends Model
{
    public $primaryKey="loan_id";

    // public function loandoc()
    // {
    //     return $this->belongsTo('App\Models\LoanDocuments','loan_id','loan_id');
    // }
    public function loandoc()
    {
        return $this->hasMany('App\Models\LoanDocuments','loan_id','loan_id');
    }

     public function refer_by()
    {
        return $this->belongsTo('App\Models\User','refered_by','id');
    }
    
     public function associate()
    {
        return $this->belongsTo('App\Models\User','assigned_to','id');
    }
     public function comments()
    {
        return $this->hasMany('App\Models\Comment','loan_id','loan_id');
    }
    public function substatus()
    {
        return $this->belongsTo('App\Models\Status','status_id','status_id');
    }
}

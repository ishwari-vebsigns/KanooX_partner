<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
    public $primaryKey="bank_id";
}

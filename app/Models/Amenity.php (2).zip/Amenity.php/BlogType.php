<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;

class BlogType extends Model
{
    public $primaryKey='blog_type_id';
}

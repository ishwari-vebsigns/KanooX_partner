<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;

class GetStarted extends Model
{
    public $primaryKey="get_started_id";
}

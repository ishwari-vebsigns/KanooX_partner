<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;

class Mis extends Model
{
     public $primaryKey="sr_id";
     protected $table='toolmiss';
}

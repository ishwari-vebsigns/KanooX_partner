<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;

class CommissionMaster extends Model
{
      public $primaryKey="commission_id";
      protected $table="commission_master";
}

<?php

namespace App\Models\Models;

use Illuminate\Database\Eloquent\Model;

class HealthInsurance extends Model
{
    public $primaryKey="health_insurance_id";
}

@extends('layouts.admin-app')
@section('content')


   
    <!-- Datatable -->
    <link href="{{$base_url}}/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link href="{{$base_url}}/css/style.css" rel="stylesheet">





    
    <!--**********************************
        Main wrapper start
    ***********************************-->
   

        <!--**********************************
            Nav header start
        ***********************************-->
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
      
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                            <h4>Hi, welcome {{Auth::user()->name}}!</h4>
                            @if(Auth::user()->role_id==2)
                            <p class="mb-0">Agent ID: {{Auth::user()->new_id}}</p>
                            @endif
                        </div>
                    </div>
                    <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Report</a></li>
                            <li class="breadcrumb-item active"><a href="javascript:void(0)">Notification Report</a></li>
                        </ol>
                    </div>
                </div>
                <!-- row -->


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                 <P></P>              <h4 class="card-title"><a href="add" style="color:white;" class="btn btn-secondary">Add Notification</a></h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example" class="display" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>Notification ID</th>
                                                <th>Notification Name</th>
                                                <th>Notification Type</th>
                                                <th>Updated At</th>
                                                <th>Status</th>
                                                <th>Action</th>


                                            </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($notifications as $notification)
                                            <tr>
                                                <td>{{$notification->notification_id}}</td>
                                                <td>{{$notification->title}}</td>
                                                @if($notification->type==1)
                                                <td><span class="badge badge-warning">Alert</span></td>
                                                @endif
                                                @if($notification->type==2)
                                                <td><span class="badge badge-secondary">Information</span></td>
                                                @endif
                                                @if($notification->type==3)
                                                <td><span class="badge badge-danger">Emergancy</span></td>
                                                @endif
                                                @if($notification->type==4)
                                                <td><span class="badge badge-dark">Image</span></td>
                                                @endif
                                                @if($notification->type==5)
                                                <td><span class="badge badge-primary">Primary</span></td>
                                                @endif
                                                <td>{{$notification->updated_at}}</td>
                                                @if($notification->status_id==1)
                                                <td><span class="badge badge-success">Active</span></td>
                                                @else
                                                <td><span class="badge badge-danger">Inactive</span></td>
                                                @endif
                                                <td><a type="button" href="{{$notification->notification_id}}" class="btn btn-dark">Details</a></td>
                                            </tr>
                                            @endforeach
                                           
                                        
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
       
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

   
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="{{$base_url}}/vendor/global/global.min.js"></script>
    <script src="{{$base_url}}/js/quixnav-init.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>    


    <!-- Datatable -->
    <script src="{{$base_url}}/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="{{$base_url}}/js/plugins-init/datatables.init.js"></script>



@endsection
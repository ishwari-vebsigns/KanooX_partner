




<div class="sidenav-overlay"></div>
<!--<div class="drag-target"></div>-->
       
<!--    <footer class="footer footer-static footer-light no-print">-->
<!--    <p class="clearfix blue-grey lighten-2 mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; 2020<a class="text-bold-800 grey darken-2" href="{{config('app.baseURL')}}" target="_blank">Fintech. </a>All rights Reserved</span><!-- <span class="float-md-right d-none d-md-block">Designed by<i class="feather icon-heart pink"></i>Vebsigns</span> -->-->
<!--        <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="feather icon-arrow-up"></i></button>-->
<!--    </p>-->
<!--</footer>-->
<!-- END: Footer-->
<style>
    .main-menu.menu-light .navigation .navigation-header {
    color: #fff;
    /* margin: 2rem 0 0.8rem 2.2rem; */
    padding: 0;
    line-height: 1.5;
    letter-spacing: .01rem;
    background: dodgerblue;
    margin-top: 10px;
    margin-bottom: 17px;
    padding: 10px;
    text-align: center;
    font-weight: 700 !important;
    margin-left: 0px;
}
.logo-image {
    width: 133px !important;
}
.main-menu.menu-light .navigation .navigation-header span {
    font-weight: 900;
    font-size: 16px;
}
/*.logo-image{*/
/*    width:200px !important;*/
/*}*/
.main-menu.menu-light .navigation>li.open>a, .main-menu.menu-light .navigation>li.sidebar-group-active>a {
    color: #fff;
    background: #542f6d;
    transition: transform .25s ease 0s;
    border-radius: 0px;
    margin-bottom: 7px;
}
.main-menu.menu-light .navigation>li {
    padding: 0 0px;
}

.main-menu.menu-light .navigation>li.nav-item>a, .main-menu.menu-light .navigation>li.sidebar-group-active>a {
    color: #fff;
    background: #542f6d;
    transition: transform .25s ease 0s;
    border-radius: 0px;
    margin-bottom: 7px;
}
#dashboard-analytics .bg-analytics {
    background: linear-gradient(118deg,#542f6d,#542f6d) !important;
}
.dot {
  height: 25px;
  width: 25px;
  background-color: #eb2a2a;
  border-radius: 50%;
  display: inline-block;
}
.flip-card {
    position: relative;
    -webkit-perspective: 800;
    -moz-perspective: 800;
    -ms-perspective: 800;
    -o-perspective: 800;
    perspective: 800;
    border-radius: 10px;
}
.widget-bank-card {
    margin: 20px;
}
.flip-card .card {
    width: 100%;
    height: 100%;
    transform-style: preserve-3d;
    transition: transform 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    border-radius: 10px;
    box-shadow: none;
    cursor: pointer;
    /* background: linear-gradient(82.27deg, #3c488d 30.13%, #505dad 127.45%) !important; */
    background: linear-gradient(82.27deg, #0a2578 30.13%, #1247e5 127.45%) !important;
}
.flip-card .card div {
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;
    -ms-backface-visibility: hidden;
    -o-backface-visibility: hidden;
    backface-visibility: hidden;
    border-radius: 10px;
    color: #d3d3d3;
    padding: 0px 8px;
    font: 16px/1.5 "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-smoothing: antialiased;
}
.flip-card .card .back {
    position: absolute;
    /* top: 15%; */
    left: 0%;
    width: 100%;
}
</style>

@php
$user=Auth::user();
$role_id=$user->role_id;
@endphp
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
  <div class="navbar-header">
    <ul class="nav navbar-nav flex-row">
      <li class="nav-item mr-auto"><a class="navbar-brand" href="javascript:void(0);">
       
             
             <img src="http://fintech.vebsignsautomation.com/web-assets/images/resources/logo.png" alt="logo" class="logo-image">
       
       
      </a></li>

    </ul>
  </div>
  <div class="shadow-bottom"></div>
  <div class="main-menu-content">
    <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">


      <!--<li class="nav-item  ">-->
      <!--  <a href="{{config('app.baseURL')}}/admin/dashboard">-->
      <!--    <i class="feather icon-home"></i>-->
      <!--    <span class="menu-title" data-i18n="">Dashboard</span>-->
          
      <!--  </a>-->
      <!--</li>-->
      
       <li class="nav-item">
                        <a href="{{config('app.baseURL')}}/admin/dashboard">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Dashboard</span>
                                                    </a>
                                                                                         
    
    </li>
      
      
      
      <li class="nav-item ">
                        <a href="{{config('app.baseURL')}}/admin/services">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Services</span>
                                                    </a>
                                                                                         
    
    </li>
    
      <li class="nav-item ">
                        <a href="javascript:void(0);">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Load Money</span>
                                                    </a>
                                                                                            
    
    </li>
    
      <li class="nav-item ">
                        <a href="javascript:void(0);">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Business Report</span>
                                                    </a>
                                                                                            
    
    </li>
    
      <li class="nav-item ">
                        <a href="javascript:void(0);">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Profile</span>
                                                    </a>
                                                                                            
    
    </li>
    
    <li class="nav-item ">
                        <a href="javascript:void(0);">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Training</span>
                                                    </a>
                                                                                            
    
    </li>
    
       <li class="nav-item ">
                        <a href="javascript:void(0);">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Help & Support</span>
                                                    </a>
                                                                                            
    
    </li>
    
     <li class="nav-item ">
                        <a href="javascript:void(0);">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Commission Structure</span>
                                                    </a>
                                                                                            
    
    </li>
    
    <li class="nav-item ">
                        <a href="javascript:void(0);">
                            <i class="feather icon-shopping-cart" style="visibility:hidden;"></i>
                            <span class="menu-title" data-i18n="">Logout</span>
                                                    </a>
                                                                                            
    
    </li>
      
      
      
      
     

            
<!--<div class="buy-now no-print" style="margin-left:20px;">-->
<!--    <a href="{{config('app.baseURL')}}" class="btn btn-danger">Switch To Website</a>-->
<!--</div>-->
              
     
            
           
            
             



            </ul>
          </div>
        </div>
<!-- END: Main Menu-->